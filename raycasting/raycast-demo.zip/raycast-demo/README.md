# skeleton3
Most skeltony of all phaser projects

_Note_: This project relies on a version of phaser that I've built and
committed into `vendor/`. This is possibly dumb and maybe I should just
pull it from npm but I didn't and I'm lazy.